<?php
/*
	 * PROSES Tambah  
	 */
class delete
{
	protected $db;
	function __construct($db)
	{
		$this->db = $db;
	}

	function delete_surat_by_substansi($substansi_id, $month, $year)
	{
		$data[] = $substansi_id;
		$data[] = $month;
		$data[] = $year;

		$sql = 'DELETE FROM surat WHERE substansi_id = ? AND MONTH(month_year) = ? AND YEAR(month_year) = ?';
		$row = $this->db->prepare($sql);
		$row->execute($data);
	}
	function delete_surat_by_sumber_surat($sumber_surat, $month, $year)
	{
		$data[] = $sumber_surat;
		$data[] = $month;
		$data[] = $year;

		$sql = 'DELETE FROM surat WHERE sumber_surat_id = ? AND MONTH(month_year) = ? AND YEAR(month_year) = ?';
		$row = $this->db->prepare($sql);
		$row->execute($data);
	}
	function delete_tindak_lanjut_by_id($idx)
	{
		$data[] = $idx;

		$sql = 'DELETE FROM tindak_lanjut WHERE id = ?';
		$row = $this->db->prepare($sql);
		$row->execute($data);
	}
}
