<?php
/*
	 * PROSES Tambah  
	 */
class create
{
	protected $db;
	function __construct($db)
	{
		$this->db = $db;
	}

	function add_surat($substansi_id, $sumber_surat_id, $amount_p, $amount_sb, $amount_stb, $date)
	{
		$data[] = $substansi_id;
		$data[] = $sumber_surat_id;
		$data[] = $amount_p;
		$data[] = $amount_sb;
		$data[] = $amount_stb;
		$data[] = $date;

		$sql = 'INSERT INTO surat (substansi_id,sumber_surat_id,amount_p,amount_sb,amount_stb,month_year) VALUES(?,?,?,?,?,?)';
		$row = $this->db->prepare($sql);
		$row->execute($data);
	}
	function add_tindak_lanjut($data)
	{
		// $data = array($sumber_surat_id, $nomor_surat, $pelapor, $terlapor_polres, $substansi_id, $substansi_ket, $status_surat, $penyelesaian_id, $penyelesaian_ket, $jawaban_pengadu, $tanggal_jawaban_pengadu, $jawaban_polres, $tanggal_jawaban_polres, $jawaban_satker, $tanggal_jawaban_satker, $tanggal_surat);

		$sql = 'INSERT INTO tindak_lanjut (sumber_surat_id, nomor_surat, pelapor, terlapor_polres, substansi_id, substansi_ket, status_surat, penyelesaian_id, penyelesaian_ket, jawaban_pengadu, tanggal_jawaban_pengadu, jawaban_polres, tanggal_jawaban_polres, jawaban_satker, tanggal_jawaban_satker, tanggal_surat) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)';
		$row = $this->db->prepare($sql);
		$row->execute($data);
	}
}
