<?php
/*
	 * PROSES TAMPIL  
	 */
class view
{
	protected $db;
	function __construct($db)
	{
		$this->db = $db;
	}

	function get_substansi()
	{
		$sql = "SELECT * FROM substansi";
		$row = $this->db->prepare($sql);
		$row->execute();
		$hasil = $row->fetchAll();
		return $hasil;
	}
	function get_sumber_surat()
	{
		$sql = "SELECT * FROM sumber_surat";
		$row = $this->db->prepare($sql);
		$row->execute();
		$hasil = $row->fetchAll();
		return $hasil;
	}
	function get_substansi_by_id($id)
	{
		$sql = "SELECT * FROM substansi WHERE id = ".$id;
		$row = $this->db->prepare($sql);
		$row->execute();
		$hasil = $row->fetchAll();
		return $hasil;
	}
	function get_sumber_surat_by_id($id)
	{
		$sql = "SELECT * FROM sumber_surat WHERE id = ".$id;
		$row = $this->db->prepare($sql);
		$row->execute();
		$hasil = $row->fetchAll();
		return $hasil;
	}
	function get_polres()
	{
		$sql = "SELECT * FROM polres";
		$row = $this->db->prepare($sql);
		$row->execute();
		$hasil = $row->fetchAll();
		return $hasil;
	}
	function get_amount_bulan_ini()
	{
		$sql = "SELECT ( SUM(amount_p) + SUM(amount_sb) + SUM(amount_stb) ) AS amount_all FROM surat WHERE MONTH(month_year) = ".date('m');
		$row = $this->db->prepare($sql);
		$row->execute();
		$hasil = $row->fetchAll();
		return $hasil;
	}
	function get_amount_tahun_ini()
	{
		$sql = "SELECT ( SUM(amount_p) + SUM(amount_sb) + SUM(amount_stb) ) AS amount_all FROM surat WHERE YEAR(month_year) = ".date('Y');
		$row = $this->db->prepare($sql);
		$row->execute();
		$hasil = $row->fetchAll();
		return $hasil;
	}
	function get_all_amount_surat_no_date()
	{
		$sql = "SELECT SUM(amount_p) AS amount_p, SUM(amount_sb) AS amount_sb, SUM(amount_stb) AS amount_stb, ( SUM(amount_p) + SUM(amount_sb) + SUM(amount_stb) ) AS amount_all FROM surat";
		$row = $this->db->prepare($sql);
		$row->execute();
		$hasil = $row->fetchAll();
		return $hasil;
	}
	function get_all_amount_surat($date_start, $date_end)
	{
		$sql = "SELECT SUM(amount_p) AS amount_p, SUM(amount_sb) AS amount_sb, SUM(amount_stb) AS amount_stb, ( SUM(amount_p) + SUM(amount_sb) + SUM(amount_stb) ) AS amount_all FROM surat WHERE month_year BETWEEN '".$date_start."' AND  '".$date_end."'";
		$row = $this->db->prepare($sql);
		$row->execute();
		$hasil = $row->fetchAll();
		return $hasil;
	}
	function get_amount_surat_by_substansi($substansi_id, $date_start, $date_end)
	{
		$sql = "SELECT SUM(amount_p) AS amount_p, SUM(amount_sb) AS amount_sb, SUM(amount_stb) AS amount_stb, ( SUM(amount_p) + SUM(amount_sb) + SUM(amount_stb) ) AS amount_all FROM surat WHERE substansi_id = ".$substansi_id." AND month_year BETWEEN '".$date_start."' AND  '".$date_end."'";
		$row = $this->db->prepare($sql);
		$row->execute();
		$hasil = $row->fetchAll();
		return $hasil;
	}

	function get_amount_surat_by_sumber_surat($sumber_surat, $date_start, $date_end)
	{
		$sql = "SELECT SUM(amount_p) AS amount_p, SUM(amount_sb) AS amount_sb, SUM(amount_stb) AS amount_stb, ( SUM(amount_p) + SUM(amount_sb) + SUM(amount_stb) ) AS amount_all FROM surat WHERE sumber_surat_id = ".$sumber_surat." AND month_year BETWEEN '".$date_start."' AND  '".$date_end."'";
		$row = $this->db->prepare($sql);
		$row->execute();
		$hasil = $row->fetchAll();
		return $hasil;
	}
	function get_amount_surat_by_substansi_sumber_surat($substansi, $sumber_surat, $month, $year)
	{
		$sql = "SELECT SUM(amount_p) AS amount_p, SUM(amount_sb) AS amount_sb, SUM(amount_stb) AS amount_stb FROM surat WHERE substansi_id = ".$substansi." AND sumber_surat_id = ".$sumber_surat." AND MONTH(month_year) = ".$month." AND YEAR(month_year) = ".$year;
		$row = $this->db->prepare($sql);
		$row->execute();
		$hasil = $row->fetchAll();
		return $hasil;
	}
	function get_current_account($username_old, $password_old)
	{
		$sql = 'SELECT * FROM users WHERE username = ? and password = md5(?)';
        $row = $this->db->prepare($sql);
        $row->execute(array($username_old, $password_old));
        $check = $row->rowCount();
		return $check;
	}

	function get_tindak_lanjut_by_id($id)
	{
		$sql = 'SELECT * FROM tindak_lanjut WHERE id = ?';
        $row = $this->db->prepare($sql);
        $row->execute(array($id));
		$hasil = $row->fetchAll();
		return $hasil;
	}
	function get_tindak_lanjut_by_single_date($month, $year)
	{
		$sql = 'SELECT *, tindak_lanjut.id AS id_tindak_lanjut, polres.name AS name_polres FROM tindak_lanjut JOIN polres ON tindak_lanjut.terlapor_polres = polres.id WHERE MONTH(tanggal_surat) = ? AND YEAR(tanggal_surat) = ?';
        $row = $this->db->prepare($sql);
        $row->execute(array($month, $year));
		$hasil = $row->fetchAll();
		return $hasil;
	}
	function get_tindak_lanjut_by_substansi_single($substansi_id, $month, $year)
	{
		$sql = 'SELECT *, tindak_lanjut.id AS id_tindak_lanjut, polres.name AS name_polres FROM tindak_lanjut JOIN polres ON tindak_lanjut.terlapor_polres = polres.id WHERE substansi_id = ? AND MONTH(tanggal_surat) = ? AND YEAR(tanggal_surat) = ?';
        $row = $this->db->prepare($sql);
        $row->execute(array($substansi_id, $month, $year));
		$hasil = $row->fetchAll();
		return $hasil;
	}
	function get_tindak_lanjut_by_sumber_surat_single($sumber_surat_id, $month, $year)
	{
		$sql = 'SELECT *, tindak_lanjut.id AS id_tindak_lanjut, polres.name AS name_polres FROM tindak_lanjut JOIN polres ON tindak_lanjut.terlapor_polres = polres.id WHERE sumber_surat_id = ? AND MONTH(tanggal_surat) = ? AND YEAR(tanggal_surat) = ?';
        $row = $this->db->prepare($sql);
        $row->execute(array($sumber_surat_id, $month, $year));
		$hasil = $row->fetchAll();
		return $hasil;
	}
	function get_signature($id)
	{
		$sql = 'SELECT * FROM signature WHERE id = ?';
        $row = $this->db->prepare($sql);
        $row->execute(array($id));
		$hasil = $row->fetchAll();
		return $hasil;
	}
	function get_tindak_lanjut_by_substansi($substansi_id, $month, $year)
	{
		$sql = "SELECT *, tindak_lanjut.id AS id_tindak_lanjut, polres.name AS name_polres, substansi.name AS name_substansi, sumber_surat.name AS name_sumber_surat FROM tindak_lanjut JOIN polres ON tindak_lanjut.terlapor_polres = polres.id JOIN substansi ON tindak_lanjut.substansi_id = substansi.id JOIN sumber_surat ON tindak_lanjut.sumber_surat_id = sumber_surat.id WHERE substansi_id = ".$substansi_id." AND MONTH(tanggal_surat) = ".$month." AND YEAR(tanggal_surat) = ".$year;
		$row = $this->db->prepare($sql);
		$row->execute();
		$hasil = $row->fetchAll();
		return $hasil;
	}
	function get_tindak_lanjut_by_sumber_surat($smber_surat_id, $month, $year)
	{
		$sql = "SELECT *, tindak_lanjut.id AS id_tindak_lanjut, polres.name AS name_polres, substansi.name AS name_substansi, sumber_surat.name AS name_sumber_surat FROM tindak_lanjut JOIN polres ON tindak_lanjut.terlapor_polres = polres.id JOIN substansi ON tindak_lanjut.substansi_id = substansi.id JOIN sumber_surat ON tindak_lanjut.sumber_surat_id = sumber_surat.id WHERE sumber_surat_id = ".$smber_surat_id." AND MONTH(tanggal_surat) = ".$month." AND YEAR(tanggal_surat) = ".$year;
		$row = $this->db->prepare($sql);
		$row->execute();
		$hasil = $row->fetchAll();
		return $hasil;
	}
	function get_tindak_lanjut_by_month($month, $year)
	{
		$sql = "SELECT *, tindak_lanjut.id AS id_tindak_lanjut, polres.name AS name_polres, substansi.name AS name_substansi, sumber_surat.name AS name_sumber_surat FROM tindak_lanjut JOIN polres ON tindak_lanjut.terlapor_polres = polres.id JOIN substansi ON tindak_lanjut.substansi_id = substansi.id JOIN sumber_surat ON tindak_lanjut.sumber_surat_id = sumber_surat.id WHERE MONTH(tanggal_surat) = ".$month." AND YEAR(tanggal_surat) = ".$year;
		$row = $this->db->prepare($sql);
		$row->execute();
		$hasil = $row->fetchAll();
		return $hasil;
	}
}
