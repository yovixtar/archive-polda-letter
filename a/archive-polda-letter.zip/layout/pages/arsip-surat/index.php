<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.2.0/css/datepicker.min.css" rel="stylesheet">


<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.2.0/js/bootstrap-datepicker.min.js"></script>

<div class="row my-4">
    <div class="col-lg-4 col-md-6 mb-md-0 mb-4">
        <div class="card">
            <div class="card-header pb-0">
                <div class="row">
                    <div class="col-lg-8 col-10">
                        <h6>Form Arsip Surat</h6>
                        <p class="text-sm mb-0">
                            Bulan <span class="font-weight-bold ms-1"><?= format_tanggal(date('Y-m-d'))[1] . " " . format_tanggal(date('Y-m-d'))[2] ?></span>
                        </p>
                    </div>
                </div>
            </div>
            <div class="card-body px-0 pb-0">
                <div class="container m-0 pb-4">
                    <form action="?page=arsip-surat&acc=form" method="POSt">
                        <label>Substansi</label>
                        <select class="form-select" aria-label="Default select example" name="substansi" required>
                            <option value="0" selected>Pilih Substansi</option>
                            <?php
                            $substansi = $run_query->get_substansi();
                            foreach ($substansi as $result) {
                            ?>
                                <option value="<?= $result["id"] ?>"><?= $result["name"] ?></option>
                            <?php
                            }
                            ?>
                        </select>

                        <label class="mt-3">Sumber Surat / Petugas</label>
                        <select class="form-select" aria-label="Default select example" name="sumber-surat" required>
                            <option value="0" selected>Pilih Sumber Surat</option>
                            <?php
                            $substansi = $run_query->get_sumber_surat();
                            foreach ($substansi as $result) {
                            ?>
                                <option value="<?= $result['id'] ?>"><?= $result['name'] ?></option>
                            <?php
                            }
                            ?>
                        </select>

                        <label class="mt-3">Jumlah Status Proses</label>
                        <input type="text" name="amount-p" class="form-control w-lg-50" placeholder="Status P" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*?)\..*/g, '$1');" required>

                        <label class="mt-3">Jumlah Status Selesai Benar</label>
                        <input type="text" name="amount-sb" class="form-control w-lg-50" placeholder="Status SB" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*?)\..*/g, '$1');" required>

                        <label class="mt-3">Jumlah Status Selesai Tidak Benar</label>
                        <input type="text" name="amount-stb" class="form-control w-lg-50" placeholder="Status STB" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*?)\..*/g, '$1');" required>

                        <label class="mt-3">Pilih Bulan</label>
                        <input type="text" name="month-year" id="datepicker" class="form-control w-lg-50" placeholder="Bulan, Tahun" required>

                        <div class="text-center">
                            <button type="submit" name="submit" class="btn bg-gradient-primary w-100 my-4 mb-2"><i class="fas fa-save"></i> Simpan</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-8">

        <?php
        $tanggal_query_start = date('Y-m-01');
        $tanggal_query_end = date('Y-m-01');
        $month_year = format_tanggal($tanggal_query_start)[1] . " " . format_tanggal($tanggal_query_start)[2];

        include "layout/components/tabel_surat_by_substansi.php";

        include "layout/components/tabel_surat_by_sumber.php";
        ?>
    </div>
    <script>
        $("#datepicker").datepicker({
            format: "yyyy-mm-dd",
            startView: "months",
            minViewMode: "months"
        });
    </script>
</div>