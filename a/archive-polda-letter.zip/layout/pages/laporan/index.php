<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.2.0/css/datepicker.min.css" rel="stylesheet">


<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.2.0/js/bootstrap-datepicker.min.js"></script>

<div class="row my-4">
    <div class="col-lg-4 col-md-6">
        <div class="col-lg-12 col-md-6 mb-md-0 mb-4">
            <div class="card">
                <div class="card-header pb-0">
                    <div class="row">
                        <div class="col-lg-8 col-10">
                            <h6>Laporan Bulanan</h6>
                            <p class="text-sm mb-0">
                                <span class="font-weight-bold ms-1">Single</span> Month
                            </p>
                        </div>
                    </div>
                </div>
                <div class="card-body px-0 pb-0">
                    <div class="container m-0 pb-4">
                        <form action="?page=laporan" method="POSt">

                            <label>Pilih Bulan</label>
                            <input type="text" name="month-year" id="datepicker" class="form-control w-lg-50" placeholder="Bulan, Tahun" onchange="javascript:document.getElementById('date-single').value = this.value" value="<?= (!empty($_POST["month-year"])) ? $_POST["month-year"] : "" ?>" required>

                            <div class="text-center">
                                <button type="submit" name="preview" value="single-month" class="btn bg-gradient-info w-100 mt-4"><i class="fas fa-search"></i> Preview</button>
                            </div>
                        </form>
                        <form action="/ekspor-pdf/arsip-surat.php" method="GET">
                            <input type="hidden" id="date-single" name="date" value="<?= (!empty($_POST["month-year"])) ? $_POST["month-year"] : "" ?>">

                            <div class="text-center">
                                <button type="submit" class="btn bg-gradient-warning w-100"><i class="far fa-file-pdf"></i> Download PDF</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>


        <div class="col-lg-12 col-md-6 mb-md-0 mb-4 mt-4">
            <div class="card">
                <div class="card-header pb-0">
                    <div class="row">
                        <div class="col-lg-8 col-10">
                            <h6>Laporan Bulanan</h6>
                            <p class="text-sm mb-0">
                                <span class="font-weight-bold ms-1">Multi</span> Months
                            </p>
                        </div>
                    </div>
                </div>
                <div class="card-body px-0 pb-0">
                    <div class="container m-0 pb-4">
                        <form action="?page=laporan" method="POSt">

                            <label>Pilih Bulan Pertama</label>
                            <input type="text" name="month-year-start" id="datepicker-2" class="form-control w-lg-50" placeholder="Bulan, Tahun" onchange="javascript:document.getElementById('date-multi-1').value = this.value" value="<?= (!empty($_POST["month-year-start"])) ? $_POST["month-year-start"] : "" ?>" required>

                            <label class="mt-3">Pilih Bulan Terakhir</label>
                            <input type="text" name="month-year-end" id="datepicker-3" class="form-control w-lg-50" placeholder="Bulan, Tahun" onchange="javascript:document.getElementById('date-multi-2').value = this.value" value="<?= (!empty($_POST["month-year-end"])) ? $_POST["month-year-end"] : "" ?>" required>

                            <div class="text-center">
                                <button type="submit" name="preview" value="multi-months" class="btn bg-gradient-info w-100 my-4 mb-3">Preview</button>
                            </div>
                        </form>
                        
                        <form action="/ekspor-pdf/arsip-surat.php" method="GET">
                            <input type="hidden" id="date-multi-1" name="date-start" value="<?= (!empty($_POST["month-year-start"])) ? $_POST["month-year-start"] : "" ?>">
                            <input type="hidden" id="date-multi-2" name="date-end" value="<?= (!empty($_POST["month-year-end"])) ? $_POST["month-year-end"] : "" ?>">

                            <div class="text-center">
                                <button type="submit" class="btn bg-gradient-warning w-100"><i class="far fa-file-pdf"></i> Download PDF</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-lg-8">
        <?php
        if (!empty($_POST["preview"])) {
            if ($_POST["preview"] == "multi-months") {
                $tanggal_query_start = $_POST['month-year-start'];
                $tanggal_query_end = $_POST['month-year-end'];

                $month_year = format_tanggal($tanggal_query_start)[1] . " " . format_tanggal($tanggal_query_start)[2] . " - " . format_tanggal($tanggal_query_end)[1] . " " . format_tanggal($tanggal_query_end)[2];
            } else {
                $tanggal_query_start = $_POST['month-year'];
                $tanggal_query_end = $_POST['month-year'];

                $month_year = format_tanggal($tanggal_query_start)[1] . " " . format_tanggal($tanggal_query_start)[2];
            }

            include "layout/components/tabel_surat_by_substansi.php";

            include "layout/components/tabel_surat_by_sumber.php";
        }
        ?>
    </div>
    <script>
        $("#datepicker").datepicker({
            format: "yyyy-mm-dd",
            startView: "months",
            minViewMode: "months"
        });
        $("#datepicker-2").datepicker({
            format: "yyyy-mm-dd",
            startView: "months",
            minViewMode: "months"
        });
        $("#datepicker-3").datepicker({
            format: "yyyy-mm-dd",
            startView: "months",
            minViewMode: "months"
        });
    </script>
</div>