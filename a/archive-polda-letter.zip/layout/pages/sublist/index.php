<div class="row my-4">
    <div class="col-lg-4 col-md-4 mb-md-0 mb-4">
        <div class="card">
            <div class="card-header pb-0">
                <div class="row">
                    <div class="col-lg-6 col-7">
                        <h6>Daftar Substansi</h6>
                        <p class="text-sm mb-0">
                            <span class="font-weight-bold ms-1">Kategori</span> Surat
                        </p>
                    </div>
                </div>
            </div>
            <div class="card-body px-0 pb-2">
                <div class="table-responsive">
                    <table class="table align-items-center mb-0">
                        <thead>
                            <tr>
                                <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">No</th>
                                <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Nama Substansi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $substansi = $run_query->get_substansi();
                            foreach ($substansi as $result) {
                            ?>
                                <tr>
                                    <td style="padding-left: 30px;">
                                        <h6 class="mb-0 text-sm"><?= $result["id"] ?></h6>
                                    </td>
                                    <td>
                                        <h6 class="mb-0 text-sm"><?= $result["name"] ?></h6>
                                    </td>
                                </tr>
                            <?php
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-4 col-md-4 mb-md-0 mb-4">
        <div class="card">
            <div class="card-header pb-0">
                <div class="row">
                    <div class="col-lg-6 col-7">
                        <h6>Daftar Petugas</h6>
                        <p class="text-sm mb-0">
                            <span class="font-weight-bold ms-1">Sumber</span> Surat
                        </p>
                    </div>
                </div>
            </div>
            <div class="card-body px-0 pb-2">
                <div class="table-responsive">
                    <table class="table align-items-center mb-0">
                        <thead>
                            <tr>
                                <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">No</th>
                                <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Nama Petugas</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $substansi = $run_query->get_sumber_surat();
                            foreach ($substansi as $result) {
                            ?>
                                <tr>
                                    <td style="padding-left: 30px;">
                                        <h6 class="mb-0 text-sm"><?= $result["id"] ?></h6>
                                    </td>
                                    <td>
                                        <h6 class="mb-0 text-sm"><?= $result["name"] ?></h6>
                                    </td>
                                </tr>
                            <?php
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-4 col-md-4 mb-md-0 mb-4">
        <div class="card">
            <div class="card-header pb-0">
                <div class="row">
                    <div class="col-lg-12 col-7">
                        <h6>Daftar PolRes</h6>
                        <p class="text-sm mb-0">
                            <span class="font-weight-bold ms-1">Kepolisian Resor</span> Jawa Tengah
                        </p>
                    </div>
                </div>
            </div>
            <div class="card-body px-0 pb-2">
                <div class="table-responsive">
                    <table class="table align-items-center mb-0">
                        <thead>
                            <tr>
                                <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">No</th>
                                <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ps-2">Nama Polres</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $polres = $run_query->get_polres();
                            foreach ($polres as $result) {
                            ?>
                                <tr>
                                    <td style="padding-left: 30px;">
                                        <h6 class="mb-0 text-sm"><?= $result["id"] ?></h6>
                                    </td>
                                    <td>
                                        <h6 class="mb-0 text-sm"><?= $result["name"] ?></h6>
                                    </td>
                                </tr>
                            <?php
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>