<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.2.0/css/datepicker.min.css" rel="stylesheet">


<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.2.0/js/bootstrap-datepicker.min.js"></script>

<div class="row my-4">
    <div class="col-lg-12 col-md-6">
        <div class="col-lg-4 col-md-6 mb-md-3 mb-4">
            <div class="card">
                <div class="card-header pb-0">
                    <div class="row">
                        <div class="col-lg-8 col-10">
                            <h6>Tambah Surat Tindak Lanjut</h6>
                            <p class="text-sm mb-0">
                                Form <span class="font-weight-bold ms-1">Tambah Surat</span>
                            </p>
                        </div>
                    </div>
                </div>
                <div class="card-body px-0 pb-0">
                    <div class="container m-0 pb-4">
                        <div class="text-center">
                            <a href="?page=form-tindak-lanjut&form=tambah">
                                <button type="button" class="btn bg-gradient-success w-100"><i class="fas fa-plus"></i> Tambah Surat</button>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-4 col-md-6">
        <div class="col-lg-12 col-md-6">
            <div class="card">
                <div class="card-header pb-0">
                    <div class="row">
                        <div class="col-lg-8 col-10">
                            <h6>Cari Surat Tindak Lanjut</h6>
                            <p class="text-sm mb-0">
                                Berdasarkan <span class="font-weight-bold ms-1">Bulan</span>
                            </p>
                        </div>
                    </div>
                </div>
                <div class="card-body px-0 pb-0">
                    <div class="container m-0 pb-4">
                        <form action="?page=tindak-lanjut" method="POST">
                            <label>Pilih Bulan</label>
                            <input type="text" name="tanggal-single" id="datepicker-3" class="form-control w-lg-50" placeholder="Bulan, Tahun" onchange="javascript:document.getElementById('tanggal-single').value = this.value" value="<?= (!empty($_POST["tanggal-single"])) ? $_POST["tanggal-single"] : "" ?>" required>

                            <div class="text-center">
                                <button type="submit" name="preview" value="single-month" class="btn bg-gradient-info w-100 mt-4"><i class="fas fa-search"></i> Preview</button>
                            </div>
                        </form>
                        <form action="/ekspor-pdf/tindak-lanjut.php" method="GET">
                            <input type="hidden" id="tanggal-single" name="tanggal" value="<?= (!empty($_POST["tanggal-single"])) ? $_POST["tanggal-single"] : "" ?>">

                            <div class="text-center">
                                <button type="submit" name="by" value="month" class="btn bg-gradient-warning w-100"><i class="far fa-file-pdf"></i> Download PDF</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-lg-4 col-md-6">
        <div class="col-lg-12 col-md-6 mb-md-0 mb-4">
            <div class="card">
                <div class="card-header pb-0">
                    <div class="row">
                        <div class="col-lg-8 col-10">
                            <h6>Cari Surat Tindak Lanjut</h6>
                            <p class="text-sm mb-0">
                                berdasarkan <span class="font-weight-bold ms-1">Substansi</span>
                            </p>
                        </div>
                    </div>
                </div>
                <div class="card-body px-0 pb-0">
                    <div class="container m-0 pb-4">
                        <form action="?page=tindak-lanjut" method="POST">

                            <label>Substansi</label>
                            <select class="form-select" aria-label="Default select example" name="substansi-id" onchange="javascript:document.getElementById('id-substansi-single').value = this.value" required>
                                <option value="0" selected>Pilih Substansi</option>
                                <?php
                                $substansi = $run_query->get_substansi();
                                foreach ($substansi as $result) {
                                ?>
                                    <option value="<?= $result["id"] ?>" <?= ($result["id"] == $_POST["substansi-id"]) ? "SELECTED" : "" ?>><?= $result["name"] ?></option>
                                <?php
                                }
                                ?>
                            </select>
                            <label class="mt-3">Pilih Bulan</label>
                            <input type="text" name="tanggal-substansi-single" id="datepicker" class="form-control w-lg-50" placeholder="Bulan, Tahun" onchange="javascript:document.getElementById('tanggal-substansi-single').value = this.value" value="<?= (!empty($_POST["tanggal-substansi-single"])) ? $_POST["tanggal-substansi-single"] : "" ?>" required>

                            <div class="text-center">
                                <button type="submit" name="preview" value="substansi-single-month" class="btn bg-gradient-info w-100 mt-4"><i class="fas fa-search"></i> Preview</button>
                            </div>
                        </form>
                        <form action="/ekspor-pdf/tindak-lanjut.php" method="GET">
                            <input type="hidden" id="id-substansi-single" name="substansi-id" value="<?= (!empty($_POST["substansi-id"])) ? $_POST["substansi-id"] : "" ?>">
                            <input type="hidden" id="tanggal-substansi-single" name="tanggal" value="<?= (!empty($_POST["tanggal-substansi-single"])) ? $_POST["tanggal-substansi-single"] : "" ?>">

                            <div class="text-center">
                                <button type="submit" name="by" value="substansi" class="btn bg-gradient-warning w-100"><i class="far fa-file-pdf"></i> Download PDF</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-lg-4 col-md-6">
        <div class="col-lg-12 col-md-6 mb-md-0 mb-4">
            <div class="card">
                <div class="card-header pb-0">
                    <div class="row">
                        <div class="col-lg-8 col-10">
                            <h6>Cari Surat Tindak Lanjut</h6>
                            <p class="text-sm mb-0">
                                berdasarkan <span class="font-weight-bold ms-1">Sumber Surat</span>
                            </p>
                        </div>
                    </div>
                </div>
                <div class="card-body px-0 pb-0">
                    <div class="container m-0 pb-4">
                        <form action="?page=tindak-lanjut" method="POST">

                            <label>Sumber Surat</label>
                            <select class="form-select" aria-label="Default select example" name="sumber-surat-id" onchange="javascript:document.getElementById('id-sumber-surat-single').value = this.value" required>
                                <option value="0" selected>Pilih Sumber Surat</option>
                                <?php
                                $sumber_surat = $run_query->get_sumber_surat();
                                foreach ($sumber_surat as $result) {
                                ?>
                                    <option value="<?= $result["id"] ?>" <?= ($result["id"] == $_POST["sumber-surat-id"]) ? "SELECTED" : "" ?>><?= $result["name"] ?></option>
                                <?php
                                }
                                ?>
                            </select>
                            <label class="mt-3">Pilih Bulan</label>
                            <input type="text" name="tanggal-sumber-surat-single" id="datepicker-2" class="form-control w-lg-50" placeholder="Bulan, Tahun" onchange="javascript:document.getElementById('tanggal-sumber-surat-single').value = this.value" value="<?= (!empty($_POST["tanggal-sumber-surat-single"])) ? $_POST["tanggal-sumber-surat-single"] : "" ?>" required>

                            <div class="text-center">
                                <button type="submit" name="preview" value="sumber-surat-single-month" class="btn bg-gradient-info w-100 mt-4"><i class="fas fa-search"></i> Preview</button>
                            </div>
                        </form>
                        <form action="/ekspor-pdf/tindak-lanjut.php" method="GET">
                            <input type="hidden" id="id-sumber-surat-single" name="sumber-surat-id" value="<?= (!empty($_POST["sumber-surat-id"])) ? $_POST["sumber-surat-id"] : "" ?>">
                            <input type="hidden" id="tanggal-sumber-surat-single" name="tanggal" value="<?= (!empty($_POST["tanggal-sumber-surat-single"])) ? $_POST["tanggal-sumber-surat-single"] : "" ?>">

                            <div class="text-center">
                                <button type="submit" name="by" value="sumber-surat" class="btn bg-gradient-warning w-100"><i class="far fa-file-pdf"></i> Download PDF</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-lg-12">
        <?php
        if (isset($_POST["preview"])) {
            if ($_POST["preview"] == "substansi-single-month") {
                $tanggal_query = $_POST["tanggal-substansi-single"];
                $month_year = format_tanggal($tanggal_query)[1] . " " . format_tanggal($tanggal_query)[2];
                foreach ($run_query->get_substansi_by_id($_POST["substansi-id"]) as $result) {
                    $title_table = "Berdasarkan Substansi : " . $result["name"];
                }
                $tindak_lanjut = $run_query->get_tindak_lanjut_by_substansi_single($_POST["substansi-id"], format_tanggal($tanggal_query)[3], format_tanggal($tanggal_query)[2]);
            } else if ($_POST["preview"] == "sumber-surat-single-month") {
                $tanggal_query = $_POST["tanggal-sumber-surat-single"];
                $month_year = format_tanggal($tanggal_query)[1] . " " . format_tanggal($tanggal_query)[2];
                foreach ($run_query->get_sumber_surat_by_id($_POST["sumber-surat-id"]) as $result) {
                    $title_table = "Berdasarkan Sumber Surat : " . $result["name"];
                }
                $tindak_lanjut = $run_query->get_tindak_lanjut_by_sumber_surat_single($_POST["sumber-surat-id"], format_tanggal($tanggal_query)[3], format_tanggal($tanggal_query)[2]);
            } else if ($_POST["preview"] == "single-month") {
                $tanggal_query = $_POST["tanggal-single"];
                $month_year = format_tanggal($tanggal_query)[1] . " " . format_tanggal($tanggal_query)[2];
                $title_table = "";
                $tindak_lanjut = $run_query->get_tindak_lanjut_by_single_date(format_tanggal($tanggal_query)[3], format_tanggal($tanggal_query)[2]);
            }
        } else {
            $tanggal_query = date('Y-m-d');
            $month_year = format_tanggal($tanggal_query)[1] . " " . format_tanggal($tanggal_query)[2];
            $title_table = "";
            $tindak_lanjut = $run_query->get_tindak_lanjut_by_single_date(format_tanggal($tanggal_query)[3], format_tanggal($tanggal_query)[2]);
        }

        include "layout/components/tabel_tindak_lanjut_sumber_surat.php";
        ?>
    </div>
</div>

<script>
    $("#datepicker").datepicker({
        format: "yyyy-mm-dd",
        startView: "months",
        minViewMode: "months"
    });
    $("#datepicker-2").datepicker({
        format: "yyyy-mm-dd",
        startView: "months",
        minViewMode: "months"
    });
    $("#datepicker-3").datepicker({
        format: "yyyy-mm-dd",
        startView: "months",
        minViewMode: "months"
    });
</script>