<div class="col-lg-12 col-md-6 mb-md-0 mb-4">
    <div class="card">
        <div class="card-header pb-0">
            <div class="row">
                <div class="col-lg-6 col-7">
                    <h6>Arsip Surat Berdasarkan Substansi</h6>
                    <p class="text-sm mb-0">
                        Bulan <span class="font-weight-bold ms-1"><?= $month_year ?></span>
                    </p>
                </div>
            </div>
        </div>
        <div class="card-body px-0 pb-2">
            <div class="table-responsive">
                <table class="table align-items-center mb-0">
                    <thead>
                        <tr>
                            <th></th>
                            <th class="text-uppercase text-secondary text-center text-xxs font-weight-bolder opacity-7">Proses</th>
                            <th class="text-uppercase text-secondary text-center text-xxs font-weight-bolder opacity-7">Selesai Benar</th>
                            <th class="text-uppercase text-secondary text-center text-xxs font-weight-bolder opacity-7">Selesai Tidak Benar</th>
                            <th class="text-uppercase text-secondary text-center text-xxs font-weight-bolder opacity-7">Persentase</th>
                            <?php
                            if ($_GET["page"] == "arsip-surat") {
                                echo '<th class="text-uppercase text-secondary text-center text-xxs font-weight-bolder opacity-7">Aksi</th>';
                            }
                            ?>


                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $substansi = $run_query->get_substansi();
                        foreach ($substansi as $result) {
                        ?>
                            <tr>
                                <td>
                                    <h6 class="mb-0 text-sm px-3"><?= $result["name"] ?></h6>
                                </td>
                                <?php
                                $jumlah_surat = $run_query->get_amount_surat_by_substansi($result['id'], $tanggal_query_start, $tanggal_query_end);
                                if (!$jumlah_surat) {
                                ?>
                                    <td>
                                        <h6 class="mb-0 text-sm text-center">0</h6>
                                    </td>
                                    <td>
                                        <h6 class="mb-0 text-sm text-center">0</h6>
                                    </td>
                                    <td>
                                        <h6 class="mb-0 text-sm text-center">0</h6>
                                    </td>
                                    <?php
                                } else {
                                    $jumlah_all_surat = $run_query->get_all_amount_surat($tanggal_query_start, $tanggal_query_end);
                                    foreach ($jumlah_all_surat as $result_jumlah_all_surat) {
                                        foreach ($jumlah_surat as $result_jumlah_surat) {
                                    ?>
                                            <td>
                                                <h6 class="mb-0 text-sm text-center"><?= (empty($result_jumlah_surat["amount_p"])) ? 0 : $result_jumlah_surat["amount_p"] ?></h6>
                                            </td>
                                            <td>
                                                <h6 class="mb-0 text-sm text-center"><?= (empty($result_jumlah_surat["amount_sb"])) ? 0 : $result_jumlah_surat["amount_sb"] ?></h6>
                                            </td>
                                            <td>
                                                <h6 class="mb-0 text-sm text-center"><?= (empty($result_jumlah_surat["amount_stb"])) ? 0 : $result_jumlah_surat["amount_stb"] ?></h6>
                                            </td>
                                            <td>
                                                <h6 class="mb-0 text-sm text-center"><?= (empty($result_jumlah_surat["amount_all"])) ? 0 : round(($result_jumlah_surat["amount_all"] / $result_jumlah_all_surat["amount_all"]) * 100) ?>%</h6>
                                            </td>
                                        <?php
                                        }
                                        if (($_GET["page"] == "arsip-surat" || ($_POST["preview"] != "multi-months")) && ($result_jumlah_surat["amount_all"] != null)) {
                                        ?>
                                            <td>
                                                <button type="submit" name="submit" class="btn bg-gradient-danger m-0" title="Delete" onclick="return confirm_delete_substansi(<?= $result['id'] ?>, <?= format_tanggal($tanggal_query_start)[3] ?>, <?= format_tanggal($tanggal_query_start)[2] ?>)"><i class="fas fa-trash-alt"></i></button>
                                            </td>
                                <?php
                                        }
                                    }
                                }
                                ?>
                            </tr>
                        <?php
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Vertically centered modal -->
<div class="modal fade" id="modal-delete-substansi" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="staticBackdropLabel">Yakin hapus Surat ?</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="?page=arsip-surat&acc=del-substansi" method="POST">
                <div class="modal-body">
                    <p>Data akan terhapus permanen!</p>
                    <input type="hidden" name="substansi" value="" id="delete-substansi-id">
                    <input type="hidden" name="month" value="" id="delete-substansi-month">
                    <input type="hidden" name="year" value="" id="delete-substansi-year">
                </div>
                <div class="modal-footer">
                    <span class="btn btn-secondary" data-bs-dismiss="modal">Close</span>
                    <button type="submit" name="submit" class="btn btn-danger">Yes, Hapus</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    function confirm_delete_substansi(substansi_id, month, year) {
        var deleteModal = new bootstrap.Modal(document.getElementById('modal-delete-substansi'));
        document.getElementById('delete-substansi-id').value = substansi_id;
        document.getElementById('delete-substansi-month').value = month;
        document.getElementById('delete-substansi-year').value = year;
        deleteModal.show();
    }
</script>