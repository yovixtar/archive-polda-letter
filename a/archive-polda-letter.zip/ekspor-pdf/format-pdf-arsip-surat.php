<?php

use Psr\Log\Test\DummyTest;

session_start();
require '../config.php';
include '../fungsi/view/view.php';

function format_tanggal($tanggal)
{
    $bulan = array(
        1 =>   'Januari',
        'Februari',
        'Maret',
        'April',
        'Mei',
        'Juni',
        'Juli',
        'Agustus',
        'September',
        'Oktober',
        'November',
        'Desember'
    );
    $pecahkan = explode('-', $tanggal);

    // variabel tanggal_indo 0 = tanggal
    // variabel tanggal_indo 1 = bulan (indonesia)
    // variabel tanggal_indo 2 = tahun
    // variabel tanggal_indo 3 = bulan (int)

    $tanggal_indo = [$pecahkan[2], $bulan[(int)$pecahkan[1]], $pecahkan[0], $pecahkan[1]];
    return $tanggal_indo;
}

$run_query = new view($config);

if (!empty($_GET["date"])) {
    $tanggal_query_start = $_GET["date"];
    $tanggal_query_end = $_GET["date"];
    $month_year = "BULAN " . format_tanggal($tanggal_query_start)[1] . " TAHUN " . format_tanggal($tanggal_query_start)[2];
} else if (!empty($_GET["date-start"]) && !empty($_GET["date-end"])) {
    $tanggal_query_start = $_GET["date-start"];
    $tanggal_query_end = $_GET["date-end"];
    $month_year = "BULAN " . format_tanggal($tanggal_query_start)[1] . " TAHUN " . format_tanggal($tanggal_query_start)[2] . " s.d BULAN " . format_tanggal($tanggal_query_end)[1] . " TAHUN " . format_tanggal($tanggal_query_end)[2];
}


?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan Bulanan</title>
    <style>
        p {
            font-size: 12px;
            font-family: serif;
        }

        table {
            border-collapse: collapse;
            width: 90%;
            margin-left: auto;
            margin-right: auto;
        }

        th {
            text-transform: uppercase;
            font-size: 12px;
        }

        td {
            font-size: 12px;
        }

        .b {
            font-weight: bold;
        }

        .text-center {
            text-align: center;
        }

        .logo {
            width: 50px;
        }

        .top-border {
            border-top: 1.5px solid black;
        }

        .bottom-border {
            border-bottom: 1.5px solid black;
        }

        .right-border {
            border-right: 1.5px solid black;
        }

        .left-border {
            border-left: 1.5px solid black;
        }

        .all-border {
            border: 1.5px solid black;
        }

        .my-0 {
            margin-top: 0;
            margin-bottom: 0;
        }

        .my-1 {
            margin-top: 4px;
            margin-bottom: 4px;
        }

        .space-height {
            height: 25px;
        }

        .space-height-2 {
            height: 17px;
        }

        .space-height-3 {
            height: 30px;
        }

        .w-1 {
            width: 5%;
        }

        .w-2 {
            width: 40%;
        }

        .w-3 {
            width: 10%;
        }

        .w-4 {
            width: 10%;
        }

        .w-5 {
            width: 10%;
        }

        .w-6 {
            width: 8%;
        }

        .w-7 {
            width: 5%;
        }

        .ps-1 {
            padding-left: 10px;
        }

        .uppercase {
            text-transform: uppercase;
        }

        .bg-cream {
            background-color: #FFCC66;
        }

        .bg-orange {
            background-color: #FF6600;
        }
    </style>
</head>

<body>
    <table>
        <tr>
            <td colspan="2" class="text-center">
                <img src="../assets/images/logo.png" class="logo">
            </td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
        </tr>
        <tr>
            <td colspan="2" class="text-center">
                <p class="my-0">KEPOLISIAN NEGARA REPUBLIK INDONESIA</p>
            </td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
        </tr>
        <tr>
            <td colspan="2" class="text-center bottom-border">
                <p class="my-0">DAERAH JAWA TENGAH</p>
            </td>
            <td></td>
            <td></td>
            <td></td>
            <td></td>
        </tr>
        <tr>
            <td colspan="7">
                <br />
            </td>
        </tr>
        <tr>
            <td colspan="7" class="text-center">
                <p class="b my-1">REKAPITULASI ANALISIS DAN EVALUASI BERDASARKAN SUBSTANSI</p>
            </td>
        </tr>
        <tr>
            <td colspan="7" class="text-center">
                <p class="b my-1">SURAT PENGADUAN MASYARAKAT POLDA JAWA TENGAH</p>
            </td>
        </tr>
        <tr>
            <td colspan="7" class="text-center">
                <p class="b my-1 uppercase"><?= $month_year ?></p>
            </td>
        </tr>
        <tr>
            <td></td>
            <td colspan="5" class=" top-border">
                <br />
            </td>
            <td></td>
        </tr>
        <tr>
            <td rowspan="2" class="all-border w-1 text-center bg-cream">
                <p class="b my-1">NO</p>
            </td>
            <td rowspan="2" class="all-border w-2 text-center bg-cream">
                <p class="b my-1">SUBSTANSI</p>
            </td>
            <td colspan="3" class="all-border text-center bg-cream">
                <p class="b my-1">JUMLAH</p>
            </td>
            <td colspan="2" rowspan="2" class="all-border text-center bg-cream">
                <p class="b my-1">PERSENTASE</p>
            </td>
        </tr>
        <tr class="text-center">
            <td class="all-border w-3 text-center bg-cream">
                <p class="b my-1">P</p>
            </td>
            <td class="all-border w-4 text-center bg-cream">
                <p class="b my-1">SB</p>
            </td>
            <td class="all-border w-5 text-center bg-cream">
                <p class="b my-1">STB</p>
            </td>
        </tr>
        <?php
        $nomor = 1;
        $substansi = $run_query->get_substansi();
        foreach ($substansi as $result) {
        ?>
            <tr>
                <td class="all-border text-center">
                    <p class="my-1"><?= $nomor ?></p>
                </td>
                <td class="all-border ps-1">
                    <p class="my-1"><?= $result["name"] ?></p>
                </td>
                <?php
                $jumlah_surat = $run_query->get_amount_surat_by_substansi($result['id'], $tanggal_query_start, $tanggal_query_end);
                if (!$jumlah_surat) {
                ?>
                    <td class="all-border text-center">
                        <p class="my-1">0</p>
                    </td>
                    <td class="all-border text-center">
                        <p class="my-1">0</p>
                    </td>
                    <td class="all-border text-center">
                        <p class="my-1">0</p>
                    </td>
                    <?php } else {
                    $jumlah_all_surat = $run_query->get_all_amount_surat($tanggal_query_start, $tanggal_query_end);
                    foreach ($jumlah_all_surat as $result_jumlah_all_surat) {
                        foreach ($jumlah_surat as $result_jumlah_surat) {
                    ?>
                            <td class="all-border text-center">
                                <p class="my-1"><?= (empty($result_jumlah_surat["amount_p"])) ? 0 : $result_jumlah_surat["amount_p"] ?></p>
                            </td>
                            <td class="all-border text-center">
                                <p class="my-1"><?= (empty($result_jumlah_surat["amount_sb"])) ? 0 : $result_jumlah_surat["amount_sb"] ?></p>
                            </td>
                            <td class="all-border text-center">
                                <p class="my-1"><?= (empty($result_jumlah_surat["amount_stb"])) ? 0 : $result_jumlah_surat["amount_stb"] ?></p>
                            </td>
                            <td class="top-border bottom-border left-border text-center w-6">
                                <p class="my-1"><?= (empty($result_jumlah_surat["amount_all"])) ? 0 : round(($result_jumlah_surat["amount_all"] / $result_jumlah_all_surat["amount_all"]) * 100) ?></p>
                            </td>
                <?php
                        }
                    }
                } ?>
                <td class="top-border bottom-border right-border text-center w-7">
                    <p class="my-1">%</p>
                </td>
            </tr>
        <?php $nomor++;
        }
        foreach ($jumlah_all_surat as $result_jumlah_all_surat) {
        ?>

            <tr>
                <td colspan="2" class="all-border text-center bg-orange">
                    <p class="my-1 b">JUMLAH</p>
                </td>
                <td class="all-border text-center bg-orange">
                    <p class="my-1 b"><?= (empty($result_jumlah_all_surat["amount_p"])) ? 0 : $result_jumlah_all_surat["amount_p"] ?></p>
                </td>
                <td class="all-border text-center bg-orange">
                    <p class="my-1 b"><?= (empty($result_jumlah_all_surat["amount_sb"])) ? 0 : $result_jumlah_all_surat["amount_sb"] ?></p>
                </td>
                <td class="all-border text-center bg-orange">
                    <p class="my-1 b"><?= (empty($result_jumlah_all_surat["amount_stb"])) ? 0 : $result_jumlah_all_surat["amount_stb"] ?></p>
                </td>
                <td class="top-border bottom-border left-border  text-center bg-orange">
                    <p class="my-1 b">100</p>
                </td>
                <td class="top-border bottom-border right-border text-center bg-orange">
                    <p class="my-1 b">%</p>
                </td>
            </tr>
        <?php
        }
        ?>
        <tr>
            <td colspan="7">
                <br />
            </td>
        </tr>
        <tr>
            <td colspan="7" class="text-center">
                <p class="b my-1">REKAPITULASI ANALISIS DAN EVALUASI BERDASARKAN SUMBER SURAT</p>
            </td>
        </tr>
        <tr>
            <td colspan="7" class="text-center">
                <p class="b my-1">SURAT PENGADUAN MASYARAKAT POLDA JAWA TENGAH</p>
            </td>
        </tr>
        <tr>
            <td colspan="7" class="text-center">
                <p class="b my-1 uppercase"><?= $month_year ?></p>
            </td>
        </tr>
        <tr>
            <td></td>
            <td colspan="5" class=" top-border">
                <br />
            </td>
            <td></td>
        </tr>
        <tr class="text-center">
            <td rowspan="2" class="all-border w-1 text-center bg-cream">
                <p class="b my-1">NO</p>
            </td>
            <td rowspan="2" class="all-border w-2 text-center bg-cream">
                <p class="b my-1">SUBSTANSI</p>
            </td>
            <td colspan="3" class="all-border text-center bg-cream">
                <p class="b my-1">JUMLAH</p>
            </td>
            <td colspan="2" rowspan="2" class="all-border text-center bg-cream">
                <p class="b my-1">PERSENTASE</p>
            </td>
        </tr>
        <tr class="text-center">
            <td class="all-border w-3 text-center bg-cream">
                <p class="b my-1">P</p>
            </td>
            <td class="all-border w-4 text-center bg-cream">
                <p class="b my-1">SB</p>
            </td>
            <td class="all-border w-5 text-center bg-cream">
                <p class="b my-1">STB</p>
            </td>
        </tr>
        <?php
        $nomor = 1;
        $substansi = $run_query->get_sumber_surat();
        foreach ($substansi as $result) {
        ?>
            <tr>
                <td class="all-border text-center">
                    <p class="my-1"><?= $nomor ?></p>
                </td>
                <td class="all-border ps-1">
                    <p class="my-1"><?= $result["name"] ?></p>
                </td>
                <?php
                $jumlah_surat = $run_query->get_amount_surat_by_sumber_surat($result['id'], $tanggal_query_start, $tanggal_query_end);
                if (!$jumlah_surat) {
                ?>
                    <td class="all-border text-center">
                        <p class="my-1">0</p>
                    </td>
                    <td class="all-border text-center">
                        <p class="my-1">0</p>
                    </td>
                    <td class="all-border text-center">
                        <p class="my-1">0</p>
                    </td>
                    <?php } else {
                    $jumlah_all_surat = $run_query->get_all_amount_surat($tanggal_query_start, $tanggal_query_end);
                    foreach ($jumlah_all_surat as $result_jumlah_all_surat) {
                        foreach ($jumlah_surat as $result_jumlah_surat) {
                    ?>
                            <td class="all-border text-center">
                                <p class="my-1"><?= (empty($result_jumlah_surat["amount_p"])) ? 0 : $result_jumlah_surat["amount_p"] ?></p>
                            </td>
                            <td class="all-border text-center">
                                <p class="my-1"><?= (empty($result_jumlah_surat["amount_sb"])) ? 0 : $result_jumlah_surat["amount_sb"] ?></p>
                            </td>
                            <td class="all-border text-center">
                                <p class="my-1"><?= (empty($result_jumlah_surat["amount_stb"])) ? 0 : $result_jumlah_surat["amount_stb"] ?></p>
                            </td>
                            <td class="top-border bottom-border left-border text-center w-6">
                                <p class="my-1"><?= (empty($result_jumlah_surat["amount_all"])) ? 0 : round(($result_jumlah_surat["amount_all"] / $result_jumlah_all_surat["amount_all"]) * 100) ?></p>
                            </td>
                <?php
                        }
                    }
                } ?>
                <td class="top-border bottom-border right-border text-center w-7">
                    <p class="my-1">%</p>
                </td>
            </tr>
        <?php $nomor++;
        }
        foreach ($jumlah_all_surat as $result_jumlah_all_surat) {
        ?>

            <tr>
                <td colspan="2" class="all-border text-center bg-orange">
                    <p class="my-1 b">JUMLAH</p>
                </td>
                <td class="all-border text-center bg-orange">
                    <p class="my-1 b"><?= (empty($result_jumlah_all_surat["amount_p"])) ? 0 : $result_jumlah_all_surat["amount_p"] ?></p>
                </td>
                <td class="all-border text-center bg-orange">
                    <p class="my-1 b"><?= (empty($result_jumlah_all_surat["amount_sb"])) ? 0 : $result_jumlah_all_surat["amount_sb"] ?></p>
                </td>
                <td class="all-border text-center bg-orange">
                    <p class="my-1 b"><?= (empty($result_jumlah_all_surat["amount_stb"])) ? 0 : $result_jumlah_all_surat["amount_stb"] ?></p>
                </td>
                <td class="top-border bottom-border left-border  text-center bg-orange">
                    <p class="my-1 b">100</p>
                </td>
                <td class="top-border bottom-border right-border text-center bg-orange">
                    <p class="my-1 b">%</p>
                </td>
            </tr>
        <?php
        }
        ?>

        <tr>
            <td colspan="7" class=" top-border">
                <br />
            </td>
        </tr>



        <tr>
            <td></td>
            <td></td>
            <td colspan="5" class="text-center">
                <p class="my-1">a.n KEPALA KEPOLISIAN DAERAH JAWA TENGAH</p>
            </td>
        </tr>
        <tr>
            <td></td>
            <td></td>
            <td colspan="5" class="text-center">
                <p class="my-1">IRWASDA</p>
            </td>
        </tr>
        <tr>
            <td colspan="7" class="">
                <br />
                <br />
                <br />
            </td>
        </tr>
        <?php
        $signature = $run_query->get_signature("1");
        foreach ($signature as $result_signature) {
        ?>
            <tr>
                <td></td>
                <td></td>
                <td colspan="5" class="text-center bottom-border">
                    <p class="my-1"><?= $result_signature["name"] ?></p>
                </td>
            </tr>
            <tr>
                <td></td>
                <td></td>
                <td colspan="5" class="text-center">
                    <p class="my-1"><?= $result_signature["nrp"] ?></p>
                </td>
            </tr>
        <?php } ?>
    </table>
</body>

</html>