<?php

if (isset($_POST["submit-tambah"])) {

    if ($_POST["substansi-id"] == 0 || $_POST["sumber-surat-id"] == 0 || $_POST["terlapor-polres"] == 0 || $_POST["status-surat"] == "") {
        alert_icon("warning", "Form Required", "Pastikan anda mengisi Substansi / Sumber Surat / Terlapor / Status", "?page=tindak-lanjut");
    } else {
        $data = array($_POST["sumber-surat-id"], $_POST["nomor-surat"], $_POST["pelapor"], $_POST["terlapor-polres"], $_POST["substansi-id"], $_POST["substansi-ket"], $_POST["status-surat"], $_POST["penyelesaian-id"], $_POST["penyelesaian-ket"], $_POST["jawaban-pengadu"], $_POST["tanggal-jawaban-pengadu"], $_POST["jawaban-polres"], $_POST["tanggal-jawaban-polres"], $_POST["jawaban-satker"], $_POST["tanggal-jawaban-satker"], $_POST["tanggal-surat"]);

        try {
            $run_query_create->add_tindak_lanjut($data);
            alert_icon("success", "Berhasil menambahkan Surat!", "Redirecting...", "?page=tindak-lanjut");
        } catch (\Throwable $th) {
            alert_icon("error", "Gagal menambahkan Surat!", "Redirecting...", "?page=tindak-lanjut");
        }
    }
} else if (isset($_POST["submit-update"])) {
    if ($_POST["substansi-id"] == 0 || $_POST["sumber-surat-id"] == 0 || $_POST["terlapor-polres"] == 0 || $_POST["status-surat"] == "") {
        alert_icon("warning", "Form Required", "Pastikan anda mengisi Substansi dan Sumber Surat", "?page=tindak-lanjut");
    } else {
        $data = array($_POST["sumber-surat-id"], $_POST["nomor-surat"], $_POST["pelapor"], $_POST["terlapor-polres"], $_POST["substansi-id"], $_POST["substansi-ket"], $_POST["status-surat"], $_POST["penyelesaian-id"], $_POST["penyelesaian-ket"], $_POST["jawaban-pengadu"], $_POST["tanggal-jawaban-pengadu"], $_POST["jawaban-polres"], $_POST["tanggal-jawaban-polres"], $_POST["jawaban-satker"], $_POST["tanggal-jawaban-satker"], $_POST["tanggal-surat"], $_POST["idx"]);

        try {
            $run_query_update->update_tindak_lanjut($data);
            alert_icon("success", "Berhasil mengupdate Surat!", "Redirecting...", "?page=tindak-lanjut");
        } catch (\Throwable $th) {
            alert_icon("error", "Gagal mengupdate Surat!", "Redirecting...", "?page=tindak-lanjut");
        }
    }
}

else {
    alert_icon("warning", "Not Allowed!", "Redirecting...", "?page=tindak-lanjut");
}
