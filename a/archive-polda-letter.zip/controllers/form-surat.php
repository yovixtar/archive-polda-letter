<?php

if (isset($_POST["submit"])) {

    if ($_POST["substansi"] == 0 || $_POST["sumber-surat"] == 0) {
        alert_icon("warning", "Form Required", "Pastikan anda mengisi Substansi dan Sumber Surat", "?page=arsip-surat");
    } else {
        $pecahkan_tanggal = explode('-', $_POST["month-year"]);
        $check_row_substansi_sumber_surat = $run_query->get_amount_surat_by_substansi_sumber_surat($_POST["substansi"], $_POST["sumber-surat"], $pecahkan_tanggal[1], $pecahkan_tanggal[0]);

        foreach ($check_row_substansi_sumber_surat as $result) {
            if (empty($result["amount_p"])) {
                try {
                    $run_query_create->add_surat($_POST["substansi"], $_POST["sumber-surat"], $_POST["amount-p"], $_POST["amount-sb"], $_POST["amount-stb"], $_POST["month-year"]);

                    alert_icon("success", "Berhasil menambahkan Surat!", "Redirecting...", "?page=arsip-surat");
                } catch (\Throwable $th) {
                    alert_icon("error", "Gagal menambahkan Surat!", "Redirecting...", "?page=arsip-surat");
                }
            } else {
                try {
                    $pecahkan_tanggal = explode('-', $_POST["month-year"]);

                    $run_query_update->update_surat($_POST["substansi"], $_POST["sumber-surat"], $_POST["amount-p"], $_POST["amount-sb"], $_POST["amount-stb"], $pecahkan_tanggal[1], $pecahkan_tanggal[0]);

                    alert_icon("success", "Berhasil mengupdate Surat!", "Redirecting...", "?page=arsip-surat");
                } catch (\Throwable $th) {
                    alert_icon("error", "Gagal mengupdate Surat!", "Redirecting...", "?page=arsip-surat");
                }
            }
        }
    }
}else{
    alert_icon("warning", "Not Allowed!", "Redirecting...", "?page=arsip-surat");
}
