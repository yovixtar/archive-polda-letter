<?php

if (isset($_POST["submit"])) {
    try {
        $run_query_delete->delete_surat_by_substansi($_POST["substansi"], $_POST["month"], $_POST["year"]);
        alert_icon("success", "Berhasil menghapus Surat!", "Redirecting...", "?page=arsip-surat");
    } catch (\Throwable $th) {
        alert_icon("error", "Gagal menghapus Surat!", "Redirecting...", "?page=arsip-surat");
    }
}
