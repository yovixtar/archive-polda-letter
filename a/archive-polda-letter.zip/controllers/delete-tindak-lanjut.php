<?php

if (isset($_POST["submit"])) {
    try {
        $run_query_delete->delete_tindak_lanjut_by_id($_POST["id-tindak-lanjut"]);
        alert_icon("success", "Berhasil menghapus Surat!", "Redirecting...", "?page=tindak-lanjut");
    } catch (\Throwable $th) {
        alert_icon("error", "Gagal menghapus Surat!", "Redirecting...", "?page=tindak-lanjut");
    }
}
